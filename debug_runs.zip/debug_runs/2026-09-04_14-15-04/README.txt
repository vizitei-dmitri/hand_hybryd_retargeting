Passive DG5F recording. No hardware commands are sent.
Joint position/error columns use radians; velocity uses rad/s.
NaN/empty/false means that a stream was unavailable at that sample.
